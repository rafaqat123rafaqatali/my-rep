export default function forgetpassword(){
    return <h1>Forget-passwords</h1>;
}