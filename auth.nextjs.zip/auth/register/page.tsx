export default function register(){
    return <h1>Register</h1>;
}